package com.mballem.demoparkapi.exception;

public class VagaDisponivelException extends RuntimeException {

}

