package com.mballem.demoparkapi.exception;

public class NewPasswordInvalidException extends RuntimeException {

}
