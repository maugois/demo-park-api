package com.mballem.demoparkapi.repository.projection;

public interface ClienteProjection {

    Long getId();
    String getNome();
    String getCpf();
}
