package com.mballem.demoparkapi.exception;

public class PasswordInvalidException extends RuntimeException {

}
